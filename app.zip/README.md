# `Earth-Live-Cams`

```python
ip = '80.32.125.254'
port = '8080'

camera = cv2.VideoCapture(f'http://{ip}:{port}/cgi-bin/faststream.jpg')
```

> ![image](https://github.com/imvickykumar999/Earth-Live-Cams/assets/50515418/d499f7b2-03e4-4642-a11b-f7f0d01b0aef)
